<?php
/*
Plugin Name: Multinews čeština
Plugin URI: http://expres-web.cz
Description: Přeloží premiovou šablonu Multinews do češtiny.
Author: Expres-Web
Version: 1.0
Author URI: http://expres-web.cz
*/

// Zjištění verze
require 'plugin-updates/plugin-update-checker.php';
$ExampleUpdateChecker = PucFactory::buildUpdateChecker(
	'https://raw.githubusercontent.com/expres-web/multinews-cestina/master/wp_metadata.json',
	__FILE__
);

// Soubor s funkcemi pro českou lokalizaci WordPressu (cs_CZ)...


// Nastavení správné cesty k překladům šablony...
function ew_multinews_cestina( $mofile, $domain='' ) {
  $custom_mofile = '';
  if ( in_array( $domain, array( 'multinews' ) ) ) {
    $pathinfo = pathinfo( $mofile );
    $custom_mofile = WP_PLUGIN_DIR . '/multinews-cestina/themes/' . $domain . '/' . $pathinfo['basename'];
  }
  if ( file_exists( $custom_mofile ) )
    return ( $custom_mofile );
  else
    return $mofile;
}
add_filter( 'load_textdomain_mofile', 'ew_multinews_cestina', 10, 2 );

?>